<?php
include "../../config/koneksi.php";


$id = $_POST['id'];
$a = mysqli_fetch_array(mysqli_query($con, "select * from gtk where id_gtk='$id'"));
// $tgllahir = explode(' - ', $a['tanggal']);
?>




<div class="form-group row">
    <div class="col-md-8 col-sm-8 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Nama Lengkap</label>
        <div class="form-group">
            <input type="hidden" name="id_gtk" id="id_gtk" value="<?= $a['id_gtk'] ?>">
            <input type="text" name="namalengkap1" id="namalengkap1" class="form-control" value="<?= $a['nama']; ?>">
        </div>
    </div>
    <div class="col-md-4 col-sm-4 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Jenis Kelamin</label>
        <div class="form-group">
            <select name="jk" id="jk" class="form-control">
                <option value="L" <?php if ($a['jk'] == 'L') {
                                        echo 'selected';
                                    } ?>>Laki-Laki</option>
                <option value="P" <?php if ($a['jk'] == 'P') {
                                        echo 'selected';
                                    } ?>>Perempuan</option>
            </select>
        </div>
    </div>
    <div class="col-md-8 col-sm-8 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Tempat</label>
        <div class="form-group">
            <input type="text" name="tempatx" id="tempatx" class="form-control" value="<?= $a['tempat']; ?>">
        </div>
    </div>
    <div class="col-md-4 col-sm-4 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Tanggal</label>
        <div class='input-group date' id='myDatepicker4'>
            <input type='text' class="form-control" name="tanggal" id="tanggal" value="<?= $a['tanggal']; ?>" />
            <span class="input-group-addon">
                <span class="fa fa-calendar"></span>
            </span>
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">NIP</label>
        <div class="form-group">
            <input type="text" name="nip" id="nip" class="form-control" value="<?= $a['nip']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">NIK</label>
        <div class="form-group">
            <input type="text" name="nik" id="nik" class="form-control" value="<?= $a['nik']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">NUPTK</label>
        <div class="form-group">
            <input type="text" name="nuptk" id="nuptk" class="form-control" value="<?= $a['nuptk']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Agama</label>
        <div class="form-group">
            <select name="agama" id="agama" class="form-control">
                <option value="Budha" <?php if ($a['agama'] == 'Budha') {
                                            echo 'selected';
                                        } ?>>Budha</option>
                <option value="Islam" <?php if ($a['agama'] == 'Islam') {
                                            echo 'selected';
                                        } ?>>Islam</option>
                <option value="Kristen" <?php if ($a['agama'] == 'Kristen') {
                                            echo 'selected';
                                        } ?>>Kristen</option>
                <option value="Hindu" <?php if ($a['agama'] == 'Hindu') {
                                            echo 'selected';
                                        } ?>>Hindu</option>
                <option value="Katholik" <?php if ($a['agama'] == 'Khatolik') {
                                                echo 'selected';
                                            } ?>>Khatolik</option>
            </select>
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Alamat</label>
        <div class="form-group">
            <input type="text" name="alamat" id="alamat" class="form-control" value="<?= $a['alamat']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Desa</label>
        <div class="form-group">
            <input type="text" name="desa" id="desa" class="form-control" value="<?= $a['desa']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Kecamatan</label>
        <div class="form-group">
            <input type="text" name="kecamatan" id="kecamatan" class="form-control" value="<?= $a['kecamatan']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Kabupaten</label>
        <div class="form-group">
            <input type="text" name="kabupaten" id="kabupaten" class="form-control" value="<?= $a['kabupaten']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Provinsi</label>
        <div class="form-group">
            <input type="text" name="provinsi" id="provinsi" class="form-control" value="<?= $a['provinsi']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Kode Pos</label>
        <div class="form-group">
            <input type="text" name="kodepos" id="kodepos" class="form-control" value="<?= $a['kodepos']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">No. Ijazah</label>
        <div class="form-group">
            <input type="text" name="no_ijazah" id="no_ijazah" class="form-control" value="<?= $a['no_ijazah']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">NIM</label>
        <div class="form-group">
            <input type="text" name="nim" id="nim" class="form-control" value="<?= $a['nim']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Universitas</label>
        <div class="form-group">
            <input type="text" name="nama_pt" id="nama_pt" class="form-control" value="<?= $a['nama_pt']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Prodi</label>
        <div class="form-group">
            <input type="text" name="prodi" id="prodi" class="form-control" value="<?= $a['prodi']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Tahun Masuk</label>
        <div class='input-group date' id='myDatepicker1'>
            <input type='text' class="form-control" name="thn_masuk" id="thn_masuk" value="<?= $a['thn_masuk']; ?>" />
            <span class="input-group-addon">
                <span class="fa fa-calendar"></span>
            </span>
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Tahun Keluar</label>
        <div class='input-group date' id='myDatepicker2'>
            <input type='text' class="form-control" name="thn_keluar" id="thn_keluar"
                value="<?= $a['thn_keluar']; ?>" />
            <span class="input-group-addon">
                <span class="fa fa-calendar"></span>
            </span>
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Status</label>
        <div class="form-group">
            <select name="status_peg" id="status_peg" class="form-control">
                <option value="GTY/PTY" <?php if ($a['status_peg'] == 'GTY/PTY') {
                                            echo 'selected';
                                        } ?>>GTY/PTY</option>
                <option value="GTT/PTT" <?php if ($a['status_peg'] == 'GTT/PTT') {
                                            echo 'selected';
                                        } ?>>GTT/PTT</option>
            </select>
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Jenis</label>
        <div class="form-group">
            <select name="jenis_ptk" id="jenis_ptk" class="form-control">
                <option value="Guru Mapel" <?php if ($a['jenis_ptk'] == 'Guru Mapel') {
                                                    echo 'selected';
                                                } ?>>Guru Mapel</option>
                <option value="Tenaga Pendidik" <?php if ($a['jenis_ptk'] == 'Tenaga Pendidik') {
                                                    echo 'selected';
                                                } ?>>Tenaga Pendidik</option>
            </select>
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">SK</label>
        <div class="form-group">
            <input type="text" name="sk_peg" id="sk_peg" class="form-control" value="<?= $a['sk_peg']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">TMT</label>
        <div class='input-group date' id='myDatepicker5'>
            <input type='text' class="form-control" name="tmt_peg" id="tmt_peg" value="<?= $a['tmt_peg']; ?>" />
            <span class="input-group-addon">
                <span class="fa fa-calendar"></span>
            </span>
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Pengangkat</label>
        <div class="form-group">
            <select name="pengangkat_peg" id="pengangkat_peg" class="form-control">
                <option value="Kepala Sekolah" <?php if ($a['pengangkat_peg'] == 'Kepala Sekolah') {
                                                    echo 'selected';
                                                } ?>>Kepala Sekolah</option>
                <option value="Ketua Yayasan" <?php if ($a['pengangkat_peg'] == 'Ketua Yayasan') {
                                                    echo 'selected';
                                                } ?>>Ketua Yayasan</option>
            </select>
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Mapel</label>
        <div class="form-group">
            <input type="text" name="mapel_peg" id="mapel_peg" class="form-control" value="<?= $a['mapel_peg']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Tugas Tambahan</label>
        <div class="form-group">
            <input type="text" name="tugas_tambahan" id="tugas_tambahan" class="form-control"
                value="<?= $a['tugas_tambahan']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">No. Tugas</label>
        <div class="form-group">
            <input type="text" name="no_tugas" id="no_tugas" class="form-control" value="<?= $a['no_tugas']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">TMT Tugas</label>
        <div class='input-group date' id='myDatepicker3'>
            <input type='text' class="form-control" name="tmt_tugas" id="tmt_tugas" value="<?= $a['tmt_tugas']; ?>" />
            <span class="input-group-addon">
                <span class="fa fa-calendar"></span>
            </span>
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Status Tugas</label>
        <div class="form-group">
            <select name="status_tugas" id="status_tugas" class="form-control">
                <option value="Induk" <?php if ($a['status_tugas'] == 'Induk') {
                                            echo 'selected';
                                        } ?>>Induk</option>
                <option value="Non Induk" <?php if ($a['status_tugas'] == 'Non Induk') {
                                                echo 'selected';
                                            } ?>>Non Induk</option>
            </select>
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">No. HP</label>
        <div class="form-group">
            <input type="text" name="no_hp" id="no_hp" class="form-control" value="<?= $a['no_hp']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Email</label>
        <div class="form-group">
            <input type="text" name="email" id="email" class="form-control" value="<?= $a['email']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Office</label>
        <div class="form-group">
            <input type="text" name="office" id="office" class="form-control" value="<?= $a['office']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Nama Facebook</label>
        <div class="form-group">
            <input type="text" name="nama_fb" id="nama_fb" class="form-control" value="<?= $a['nama_fb']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">URL Facebook</label>
        <div class="form-group">
            <input type="text" name="url_fb" id="url_fb" class="form-control" value="<?= $a['url_fb']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Nama Instagram</label>
        <div class="form-group">
            <input type="text" name="nama_ig" id="nama_ig" class="form-control" value="<?= $a['nama_ig']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">URL Instagram</label>
        <div class="form-group">
            <input type="text" name="url_ig" id="url_ig" class="form-control" value="<?= $a['url_ig']; ?>">
        </div>
    </div>
    <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Password</label>
        <div class="form-group">
            <input type="text" name="password" id="password" class="form-control" value="<?= $a['password']; ?>">
        </div>
    </div>
    <!-- <div class="col-md-6 col-sm-6 ">
        <label class="col-form-label col-md-6 col-sm-6 ">Pass</label>
        <div class="form-group">
            <input type="text" name="pass" id="pass" class="form-control" value="<?= $a['pass']; ?>">
        </div>
    </div> -->
    <label class="col-form-label col-md-2 col-sm-2 ">Foto</label>
    <div class="col-md-10 col-sm-10 ">
        <div class="form-group">
            <input type="hidden" name="del" id="del" value="<?= $a['foto'] ?>">
            <input type="file" name="foto1" id="foto1" class="foto1" placeholder="Judul Galeri">
            <img src="../img/GTK/<?= $a['foto'] ?>" class="img-thumbnail shadow p-3" width="250px">

        </div>

    </div>
</div>


<script type="text/javascript">
$(function() {
    $('#myDatepicker').datetimepicker();
});
$('#myDatepicker1').datetimepicker({
    format: 'YYYY'
});
$('#myDatepicker2').datetimepicker({
    format: 'YYYY'
});
$('#myDatepicker3').datetimepicker({
    format: 'YYYY-MM-DD'
});
$('#myDatepicker4').datetimepicker({
    format: 'YYYY-MM-DD'
});

$('#myDatepicker5').datetimepicker({
    format: 'YYYY-MM-DD'
});
</script>