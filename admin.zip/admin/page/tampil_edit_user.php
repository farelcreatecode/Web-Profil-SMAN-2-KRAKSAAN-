<?php
include "../../config/koneksi.php";


$id = $_POST['id'];
$a = mysqli_fetch_array(mysqli_query($con, "select * from user where id_user='$id'"));

?>




<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Nama Lengkap</label>
    <div class="col-md-10 col-sm-10 ">
        <div class="form-group">
            <input type="hidden" name="id_user" value="<?= $a['id_user'] ?>">
            <input type="text" name="ty_nama_lengkap" id="ty_nama_lengkap" class="form-control"
                value="<?= $a['nama_lengkap']; ?>">
        </div>
    </div>
</div>
<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Nama Pengguna</label>
    <div class="col-md-10 col-sm-10 ">
        <div class="form-group">
            <input type="text" name="username" id="username" class="form-control" value="<?= $a['username']; ?>">
        </div>
    </div>
</div>
<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Password</label>
    <div class="col-md-10 col-sm-10 ">
        <div class="form-group">
            <input type="text" name="pass" id="pass" class="form-control" value="<?= $a['pass']; ?>">
        </div>
    </div>
</div>
<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Foto</label>
    <div class="col-md-10 col-sm-10 ">
        <div class="form-group">
            <input type="hidden" name="del" id="del" value="<?= $a['foto'] ?>">
            <input type="file" name="foto1" id="foto1" class="foto1" placeholder="Judul Galeri">
            <img src="../img/user/<?= $a['foto'] ?>" class="img-thumbnail shadow p-3" width="250px">
        </div>
    </div>
</div>