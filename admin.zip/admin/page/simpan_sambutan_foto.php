<?php
include "../../config/koneksi.php";
$id = $_POST['id'];
$delfoto = $_POST['delfoto'];
$nama = basename($_FILES["foto"]["name"]);

$target_directory = "../../img/";
$newfilename = $target_directory . $nama;
$newdel = $target_directory . $delfoto;


if (move_uploaded_file($_FILES["foto"]["tmp_name"], $newfilename)) {
    $sql = mysqli_query($con, "update sambutan set foto='$nama' where id_sambutan='$id'");
    unlink($newdel);
}