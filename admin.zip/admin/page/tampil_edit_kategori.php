<?php
include "../config/koneksi.php";


$id = $_POST['id'];
$a = mysqli_fetch_array(mysqli_query($con, "select * from kategori where id_kategori='$id'"));

?>

<input type="hidden" class="form-control" name="idkat" value="<?= $a['id_kategori']?>">
<textarea rows="5" class="form-control " name="kat"><?= $a['kategori']?></textarea>
