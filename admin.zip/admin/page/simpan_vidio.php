<?php
include "../config/koneksi.php";

$des = $_POST['des'];
$link = $_POST['link'];
// $cek = $_POST['cek'];
// if ($cek == 'Y') {
//     $cb = 'Y';
// } else {
//     $cb = 'T';
// }

// mysqli_query($con, "update visi set visi='$visi', misi='$misi', tujuan='$tujuan' where id_visi='$idv'");
mysqli_query($con, "insert into vidio(deskripsi,link) value('$des','$link')");