<?php
include "../../config/koneksi.php";

$nama       = $_POST['nama_lengkap'];
$user       = $_POST['username'];
$md5       = md5($_POST['pass']);
$pass       = $_POST['pass'];
$namafoto = basename($_FILES["foto"]["name"]);

$target_directory = "../../img/user/";
$target_file = $target_directory . basename($_FILES["foto"]["name"]);   //name is to get the file name of uploaded file
$filetype = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
$newfilename = $target_directory . $namafoto;

if (move_uploaded_file($_FILES["foto"]["tmp_name"], $newfilename)) {
    $sql = mysqli_query($con, "insert into user
(nama_lengkap,username,password,pass,foto
)
value
('$nama','$user','$md5','$pass','$namafoto')");
}