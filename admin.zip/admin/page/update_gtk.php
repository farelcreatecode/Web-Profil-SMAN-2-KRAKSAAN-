<?php
include "../../config/koneksi.php";
$id = $_POST['id'];
$namalengkap = $_POST['namalengkap'];
$vjk = $_POST['vjk'];
$vnip = $_POST['vnip'];
$vnik = $_POST['vnik'];
$vnuptk = $_POST['vnuptk'];
$vtempat = $_POST['vtempat'];
$vtanggal = $_POST['vtanggal'];
$vagama = $_POST['vagama'];
$valamat = $_POST['valamat'];
$vdesa = $_POST['vdesa'];
$vkecamatan = $_POST['vkecamatan'];
$vkabupaten = $_POST['vkabupaten'];
$vprovinsi = $_POST['vprovinsi'];
$vkodepos = $_POST['vkodepos'];
$vno_ijazah = $_POST['vno_ijazah'];
$vnim = $_POST['vnim'];
$vnama_pt = $_POST['vnama_pt'];
$vprodi = $_POST['vprodi'];
$vthn_masuk = $_POST['vthn_masuk'];
$vthn_keluar = $_POST['vthn_keluar'];
$vstatus_peg = $_POST['vstatus_peg'];
$vjenis_ptk = $_POST['vjenis_ptk'];
$vsk_peg = $_POST['vsk_peg'];
$vtmt_peg = $_POST['vtmt_peg'];
$vpengangkat_peg = $_POST['vpengangkat_peg'];
$vmapel_peg = $_POST['vmapel_peg'];
$vtugas_tambahan = $_POST['vtugas_tambahan'];
$vno_tugas = $_POST['vno_tugas'];
$vtmt_tugas = $_POST['vtmt_tugas'];
$vstatus_tugas = $_POST['vstatus_tugas'];
$vno_hp = $_POST['vno_hp'];
$vemail = $_POST['vemail'];
$voffice = $_POST['voffice'];
$vnama_fb = $_POST['vnama_fb'];
$vurl_fb = $_POST['vurl_fb'];
$vnama_ig = $_POST['vnama_ig'];
$vurl_ig = $_POST['vurl_ig'];
$vpassword = $_POST['vpassword'];
$md5pass = md5($_POST['vpassword']);

$del = $_POST['del'];
$namafoto = basename($_FILES["foto"]["name"]);
$target_directory = "../../img/GTK/";
$target_file = $target_directory . basename($_FILES["foto"]["name"]);   //name is to get the file name of uploaded file
// $filetype = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
$newfilename = $target_directory . $namafoto;
$newdel = $target_directory . $del;
if (move_uploaded_file($_FILES["foto"]["tmp_name"], $newfilename)) {
    $sql = mysqli_query($con, "update gtk set foto='$namafoto' where id='$id'");
    unlink($newdel);
} else {
    mysqli_query($con, "update gtk set 
    nama='$namalengkap'
    , jk='$vjk'
    , nip='$vnip'
    , nik='$vnik'
    , nuptk='$vnuptk'
    , tempat='$vtempat'
    , tanggal='$vtanggal'
    , agama='$vagama'
    , alamat='$valamat'
    , desa='$vdesa'
    , kecamatan='$vkecamatan'
    , kabupaten='$vkabupaten'
    , provinsi='$vprovinsi'
    , kodepos='$vkodepos'
    , no_ijazah='$vno_ijazah'
    , nim='$vnim'
    , nama_pt='$vnama_pt'
    , prodi='$vprodi'
    , thn_masuk='$vthn_masuk'
    , thn_keluar='$vthn_keluar'
    , status_peg='$vstatus_peg'
    , jenis_ptk='$vjenis_ptk'
    , sk_peg='$vsk_peg'
    , tmt_peg='$vtmt_peg'
    , pengangkat_peg='$vpengangkat_peg'
    , mapel_peg='$vmapel_peg'
    , tugas_tambahan='$vtugas_tambahan'
    , no_tugas='$vno_tugas'
    , tmt_tugas='$vtmt_tugas'
    , status_tugas='$vstatus_tugas'
    , no_hp='$vno_hp'
    , email='$vemail'
    , office='$voffice'
    , nama_fb='$vnama_fb'
    , url_fb='$vurl_fb'
    , nama_ig='$vnama_ig'
    , url_ig='$vurl_ig'
    , password='$vpassword'
    , pass='$md5pass'
    where id_gtk='$id'");
}



