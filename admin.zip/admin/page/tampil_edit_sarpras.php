<?php
include "../../config/koneksi.php";


$id = $_POST['id'];
$a = mysqli_fetch_array(mysqli_query($con, "select * from sarpras where id_sarpras='$id'"));

?>




<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Sarpras</label>
    <div class="col-md-10 col-sm-10 ">
        <div class="form-group">
            <input type="hidden" name="id_sarpras" value="<?= $a['id_sarpras'] ?>">
            <input type="text" name="sarpras1" value="<?= $a['sarpras'] ?>" class="form-control">
        </div>

    </div>
</div>