<?php
include "../config/koneksi.php";
session_start();

	$user = $_POST['user'];
	$pass = md5($_POST['pass']);
	$level= $_POST['level'];
	if ($level == "admin") {
		
		$sql = mysqli_query($con,"select * from user WHERE username='$user' AND password='$pass'");
		$row = mysqli_num_rows($sql);
		$data = mysqli_fetch_array($sql);
	
		if($row == 1){
            echo "ok";	
			$_SESSION['id_user'] = $data['id_user'];
			$_SESSION['nama_lengkap'] = $data['nama_lengkap'];
            $_SESSION['username'] = $data['username'];
			$_SESSION['status'] = "login";
            
		}else {
			echo "gagal";
		}

	} else {		
		$sql1 = mysqli_query($con,"select * from gtk WHERE id_gtk='$user' AND password='$pass'");
		$cari = mysqli_num_rows($sql1);
		$gtk = mysqli_fetch_array($sql1);
	
		if($cari == 1){
            echo "ok";	
			$_SESSION['id_user'] = $gtk['id_user'];
			$_SESSION['nama_lengkap'] = $gtk['nama'];
            $_SESSION['jk'] = $gtk['jk'];
            $_SESSION['nip'] = $gtk['nip'];
            $_SESSION['nik'] = $gtk['nik'];
            $_SESSION['tempat'] = $gtk['tempat'];
            $_SESSION['tanggal'] = $gtk['tanggal'];
            $_SESSION['alamat'] = $gtk['alamat'];           
			$_SESSION['status'] = "login";
            
		}else {
			echo "gagal";
		}
	}
	
	