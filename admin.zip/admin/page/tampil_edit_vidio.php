<?php
include "../config/koneksi.php";

$id = $_POST['id'];
$a = mysqli_fetch_array(mysqli_query($con, "select * from vidio where id_vidio='$id'"));
?>



<div class="form-group row mb-2">
    <label class="col-form-label col-md-2 col-sm-2 ">Deskripsi</label>
    <div class="col-md-10 col-sm-10 ">
        <input type="hidden" class="form-control" name="idvidio" value="<?= $a['id_vidio']?>">
        <textarea rows="5" class="form-control ckeditor" name="deskripsi"><?= $a['deskripsi']?></textarea>
    </div>
</div>
<div class="form-group row mb-2">
    <label class="col-form-label col-md-2 col-sm-2 ">Link</label>
    <div class="col-md-10 col-sm-10 ">
        <textarea rows="5" class="form-control ckeditor" name="linkvidio"><?= $a['link']?></textarea>
    </div>
</div>