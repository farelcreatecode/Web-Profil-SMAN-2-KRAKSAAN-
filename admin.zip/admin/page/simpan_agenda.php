<?php
include "../../config/koneksi.php";

$awal = $_POST['mulai'];
$akhir = $_POST['akhir'];
$agenda = $_POST['agenda'];
$pj = $_POST['pj'];
$tgl = $awal . ' - ' . $akhir;

// mysqli_query($con, "update visi set visi='$visi', misi='$misi', tujuan='$tujuan' where id_visi='$idv'");
mysqli_query($con, "insert into agenda(id_gtk,tanggal,agenda) value('$pj','$tgl','$agenda')");