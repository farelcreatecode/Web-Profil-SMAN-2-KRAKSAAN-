<?php
include "../../config/koneksi.php";
$id = $_POST['id'];
$delweb = $_POST['delweb'];
$nama = basename($_FILES["foto"]["name"]);

$target_directory = "../../img/";
$newfilename = $target_directory . $nama;
$newdel = $target_directory . $delweb;


if (move_uploaded_file($_FILES["foto"]["tmp_name"], $newfilename)) {
    $sql = mysqli_query($con, "update identitas set logo_web='$nama' where id_identitas='$id'");
    unlink($newdel);
}