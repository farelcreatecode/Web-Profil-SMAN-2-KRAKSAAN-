<?php
include "../config/koneksi.php";

$idv = $_POST['idvidio'];
$des = $_POST['deskripsi'];
$link = $_POST['linkvidio'];



mysqli_query($con, "update vidio set deskripsi='$des', link='$link' where id_vidio='$idv'");
// mysqli_query($con, "insert into vidio(deskripsi,link,status) value('$des','$link','$cek')");