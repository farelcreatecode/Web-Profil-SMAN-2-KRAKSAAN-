<?php
include "../../config/koneksi.php";


$id = $_POST['id'];
$a = mysqli_fetch_array(mysqli_query($con, "select * from berita where id_berita='$id'"));

?>



<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Judul Berita</label>
    <div class="col-md-10 col-sm-10 ">


        <input type="hidden" name="id" id="id" value="<?= $a['id_berita'] ?>" class="form-control">
        <input type="text" name="judul" id="judul" value="<?= $a['berita'] ?>" class="form-control">
    </div>
</div>
<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Deskripsi</label>
    <div class="col-md-10 col-sm-10 ">
        <textarea rows="5" class="form-control ckeditor" name="deskripsi"
            id="deskripsi"><?= $a['deskripsi'] ?></textarea>
    </div>
</div>
<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Kategori</label>
    <div class="col-md-10 col-sm-10 ">
        <select name="kat" class="form-control" id="kat">
            <?php
            $cari = mysqli_query($con, 'select * from kategori');
            while ($r = mysqli_fetch_array($cari)) {
            ?>
            <option value="<?= $r['id_kategori'] ?>" <?php
                                                            if ($a['id_kategori'] == $r['id_kategori']) {
                                                                echo 'selected';
                                                            } else {
                                                                echo '';
                                                            }
                                                            ?>><?= $r['kategori'] ?></option>
            <?php } ?>
        </select>
    </div>
</div>

<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Foto</label>
    <div class="col-md-10 col-sm-10 ">
        <input type="hidden" name="del" id="del" value="<?= $a['foto'] ?>">
        <input type="file" name="foto" id="foto" class="foto">
        <img src="../img/berita/<?= $a['foto'] ?>" class="img-thumbnail shadow p-3" width="250px">
    </div>
</div>
<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Status</label>
    <div class="col-md-10 col-sm-10 ">

        <select name="status" id="status" class="form-control">
            <option value="Y" <?php if ($a['status'] == 'Y') {
                                    echo 'selected';
                                } ?>>Aktif</option>
            <option value="A" <?php if ($a['status'] == 'A') {
                                    echo 'selected';
                                } ?>>Antrian</option>
            <option value="T" <?php if ($a['status'] == 'T') {
                                    echo 'selected';
                                } ?>>Tidak Aktif</option>
        </select>
    </div>
</div>