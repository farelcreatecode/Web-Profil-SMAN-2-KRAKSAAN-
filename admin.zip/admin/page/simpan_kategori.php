<?php
include "../config/koneksi.php";

$kategori = $_POST['kategori'];


// mysqli_query($con, "update visi set visi='$visi', misi='$misi', tujuan='$tujuan' where id_visi='$idv'");
mysqli_query($con, "insert into kategori(kategori) value('$kategori')");