<?php
include '../config/koneksi.php';

$idi = $_POST['idi'];
$nps = $_POST['nps'];
$nms = $_POST['nms'];
$web = $_POST['web'];
$eml = $_POST['eml'];
$alm = $_POST['alm'];
$deskripsi_sekolah = $_POST['deskripsi_sekolah'];
$des = $_POST['des'];
$kec = $_POST['kec'];
$kab = $_POST['kab'];
$akr = $_POST['akr'];
$fac = $_POST['fac'];
$nmk = $_POST['nmk'];
$not = $_POST['not'];


$sql = mysqli_query($con, "update identitas set nama_sekolah='$nms', nama_website='$web', 
npsn='$nps', email='$eml', alamat='$alm', desa='$des', kecamatan='$kec', kabupaten='$kab',
akreditasi='$akr', facebook='$fac', nama_ks='$nmk', no_telp='$not', deskripsi_sekolah='$deskripsi_sekolah' 
where id_identitas='$idi'");
// mysqli_query($con, 'insert into vidio(deskripsi,link,status) value('$des','$link','$cek')');