<?php
include "../../config/koneksi.php";
$id = $_POST['id'];
$nama_ks = $_POST['nama_ks'];
$sambutan = $_POST['sambutan'];

$sql = mysqli_query($con, "update sambutan set nama_ks='$nama_ks', sambutan='$sambutan' where id_sambutan='$id'");