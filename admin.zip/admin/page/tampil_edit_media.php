<?php
include "../config/koneksi.php";

$id = $_POST['id'];
$a = mysqli_fetch_array(mysqli_query($con, "select * from profil_info where id_profil='$id'"));
?>


<div class="form-group row mb-2">
    <label class="col-form-label col-md-2 col-sm-2 ">Kategori</label>
    <div class="col-md-10 col-sm-10 ">
        <select name="kategori" id="kat1" class="form-control">
            <?php
            $cari = mysqli_query($con, "select * from kategori");
            while($ca = mysqli_fetch_array($cari)){
            
            ?>
            <option value="<?= $ca['id_kategori']?>"
            <?php
            if ($a['kategori'] == $ca['id_kategori']) {
                echo "selected";
            } else {
                echo "";
            }
            
            ?>
            ><?= $ca['kategori']?></option>
            <?php }?>
        </select>
    </div>
</div>
<div class="form-group row mb-2">
    <label class="col-form-label col-md-2 col-sm-2 ">Judul *</label>
    <div class="col-md-10 col-sm-10 ">
        <input type="hidden" name="id_media" id="id_media" value="<?= $a['id_profil']?>" >
        <input type="text" class="form-control" name="judul_media1" id="judul1" value="<?= $a['judul']?>" >
        <!-- <textarea rows="3" class="form-control ckeditor" name="judul_media1" id="judul1"><?= $a['judul']?></textarea> -->
    </div>
</div>
<div class="form-group row mb-2">
    <label class="col-form-label col-md-2 col-sm-2 ">Isi *</label>
    <div class="col-md-10 col-sm-10 ">
        <textarea rows="5" class="form-control ckeditor" name="isi1" id="isi1"><?= $a['detail']?></textarea>
    </div>
</div>
<div class="form-group row mb-2">
    <label class="col-form-label col-md-2 col-sm-2 ">Foto *</label>
    <div class="col-md-10 col-sm-10 ">
        <img src="../img/<?= $a['foto']?>" alt="" class="img-thumbnail img-fluid" style="height:250px;">
        <input type="file" name="foto1" id="foto_media1" class="form-control">
        <input type="hidden" name="foto12" id="del" class="form-control" value="<?= $a['foto']?>">
    </div>
</div>
<!-- <script src="../js/tinymce/tinymce.min.js"></script> -->
<!-- <script src="../js/tinymce/init.js"></script> -->
<script type="text/javascript">
// tinymce.init({
//     selector: 'textarea',  // change this value according to your HTML
//     plugins: 'a_tinymce_plugin',
//     a_plugin_option: true,
//     a_configuration_option: 400
// });
tinymce.init({
  selector: 'textarea#isi1',
  height: 500,
  plugins: [
    'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
    'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
    'insertdatetime', 'media', 'table', 'help', 'wordcount'
  ],
  toolbar: 'undo redo | blocks | ' +
  'bold italic backcolor | alignleft aligncenter ' +
  'alignright alignjustify | bullist numlist outdent indent | ' +
  'removeformat | help',
  content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:16px }'
});
</script>