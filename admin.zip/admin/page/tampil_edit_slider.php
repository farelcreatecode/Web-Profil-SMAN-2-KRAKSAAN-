<?php
include "../../config/koneksi.php";


$id = $_POST['id'];
$a = mysqli_fetch_array(mysqli_query($con, "select * from slider where id='$id'"));

?>




<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Foto</label>
    <div class="col-md-10 col-sm-10 ">
        <div class="form-group">
            <input type="hidden" name="id_slider" id="id_slider" value="<?= $a['id'] ?>">
            <input type="hidden" name="del" id="del" value="<?= $a['nama'] ?>">
            <input type="file" name="foto1" id="foto1" class="foto1" placeholder="Judul slider">
            <img src="../img/slider/<?= $a['nama'] ?>" class="img-thumbnail shadow p-3" width="250px">

        </div>

    </div>
</div>