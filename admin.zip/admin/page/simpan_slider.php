<?php
include "../../config/koneksi.php";

// $ket = $_POST['ket'];


$nama = basename($_FILES["foto"]["name"]);

$target_directory = "../../img/slider/";
$target_file = $target_directory . basename($_FILES["foto"]["name"]);
$newfilename = $target_directory . $nama;
if (move_uploaded_file($_FILES["foto"]["tmp_name"], $newfilename)) {
    $sql = mysqli_query($con, "insert into slider(nama) value('$nama')");
}