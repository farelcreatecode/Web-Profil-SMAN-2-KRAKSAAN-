<?php
include "../config/koneksi.php";
$ids = $_POST['idkat'];
$kategori = $_POST['kat'];


mysqli_query($con, "update kategori set kategori='$kategori' where id_kategori='$ids'");
// mysqli_query($con, "insert into vidio(deskripsi,link,status) value('$des','$link','$cek')");