<?php
include "../../config/koneksi.php";


$id = $_POST['id'];
$a = mysqli_fetch_array(mysqli_query($con, "select * from program where id_program='$id'"));

?>




<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Divisi</label>
    <div class="col-md-10 col-sm-10 ">
        <div class="form-group">
            <input type="hidden" name="id" id="id" value="<?= $a['id_program'] ?>">
            <input type="text" name="divisi1" id="divisi1" placeholder="Divisi" class="form-control"
                value="<?= $a['divisi'] ?>">
        </div>

    </div>
</div>
<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Deskripsi</label>
    <div class="col-md-10 col-sm-10 ">
        <div class="form-group">
            <textarea name="deskripsi1" id="deskripsi1" rows="10" class="form-control"
                placeholder="Deskripsi"><?= $a['deskripsi'] ?></textarea>
        </div>

    </div>
</div>
<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Foto</label>
    <div class="col-md-10 col-sm-10 ">
        <div class="form-group">
            <input type="hidden" name="del" id="del" value="<?= $a['foto'] ?>">
            <input type="file" name="foto1" id="foto1" class="foto1">
            <img src="../img/program/<?= $a['foto'] ?>" alt="foto" width="250px">
        </div>

    </div>
</div>