<?php
include "../config/koneksi.php";
$id = $_POST['id'];
$kat = $_POST['kat'];
$del = $_POST['del'];
$judul = $_POST['judul'];
$isi = $_POST['isi'];
$tgl = date('Y-m-d');
$nama_foto = basename($_FILES["foto"]["name"]);


$target_directory = "../../img/";
$simpan = $target_directory . $nama_foto;
$newdel = $target_directory . $del;

if (move_uploaded_file($_FILES["foto"]["tmp_name"], $simpan)) {
    $sql = mysqli_query($con, "update profil_info set kategori='$kat', judul='$judul', detail='$isi', foto='$nama_foto', waktu='$tgl' where id_profil='$id'");
    unlink($newdel);
}