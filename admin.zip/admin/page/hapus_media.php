<?php
include "../config/koneksi.php";

$id = $_POST['id'];

$a = mysqli_fetch_array(mysqli_query($con, "select * from profil_info where id_profil='$id'"));
$cek = $a['foto'];
$target_directory = "../../img/";
$newdel = $target_directory.$cek;
unlink($newdel);
mysqli_query($con, "delete from profil_info where id_profil='$id'");
echo "ok";