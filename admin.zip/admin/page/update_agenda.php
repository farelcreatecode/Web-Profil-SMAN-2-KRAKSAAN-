<?php
include "../../config/koneksi.php";
$ida = $_POST['id_agenda'];
$awal = $_POST['mulai1'];
$akhir = $_POST['akhir1'];
$agenda = $_POST['agenda1'];
$pj = $_POST['pj1'];
$tgl = $awal . ' - ' . $akhir;


mysqli_query($con, "update agenda set tanggal='$tgl', agenda='$agenda', id_gtk='$pj' where id_agenda='$ida'");
// mysqli_query($con, "insert into vidio(deskripsi,link,status) value('$des','$link','$cek')");