<?php
include "../config/koneksi.php";

$kat = $_POST['kat'];
$judul = $_POST['judul'];
$isi = $_POST['isi'];
$tgl = date('Y-m-d');
$nama_foto = basename($_FILES["foto"]["name"]);

// mysqli_query($con, "insert into vidio(deskripsi,link) value('$des','$link')");
$target_directory = "../../img/";
$target_file = $target_directory . basename($_FILES["foto"]["name"]);   //name is to get the file name of uploaded file
// $filetype = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
$newfilename = $target_directory . $nama_foto;

if (move_uploaded_file($_FILES["foto"]["tmp_name"], $newfilename)) {
    $sql = mysqli_query($con, "insert into profil_info(kategori,judul,detail,foto,waktu) value('$kat','$judul','$isi','$nama_foto','$tgl')");
}