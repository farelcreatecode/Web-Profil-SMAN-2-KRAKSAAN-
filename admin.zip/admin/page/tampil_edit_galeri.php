<?php
include "../../config/koneksi.php";


$id = $_POST['id'];
$a = mysqli_fetch_array(mysqli_query($con, "select * from galeri where id_galeri='$id'"));

?>




<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Keterangan</label>
    <div class="col-md-10 col-sm-10 ">
        <div class="form-group">
            <input type="hidden" name="id_galeri" id="id_galeri" value="<?= $a['id_galeri'] ?>">
            <textarea name="ket1" id="ket1" class="form-control" rows="5"><?= $a['keterangan'] ?></textarea>
        </div>

    </div>
</div>
<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Foto</label>
    <div class="col-md-10 col-sm-10 ">
        <div class="form-group">
            <input type="hidden" name="del" id="del" value="<?= $a['foto'] ?>">
            <input type="file" name="foto1" id="foto1" class="foto1" placeholder="Judul Galeri">
            <img src="../img/galeri/<?= $a['foto'] ?>" class="img-thumbnail shadow p-3" width="250px">

        </div>

    </div>
</div>