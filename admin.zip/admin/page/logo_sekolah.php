<?php
include "../../config/koneksi.php";
$id = $_POST['id'];
$delsekolah = $_POST['delsekolah'];
$nama = basename($_FILES["foto"]["name"]);

$target_directory = "../../img/";
$newfilename = $target_directory . $nama;
$newdel = $target_directory . $delsekolah;


if (move_uploaded_file($_FILES["foto"]["tmp_name"], $newfilename)) {
    $sql = mysqli_query($con, "update identitas set logo_sekolah='$nama' where id_identitas='$id'");
    unlink($newdel);
}