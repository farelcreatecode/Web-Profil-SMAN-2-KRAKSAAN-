<?php
include "../config/koneksi.php";

$id = $_POST['id'];
mysqli_query($con, "delete from vidio where id_vidio='$id'");
echo 'ok';
// mysqli_query($con, "insert into vidio(deskripsi,link,status) value('$des','$link','$cek')");