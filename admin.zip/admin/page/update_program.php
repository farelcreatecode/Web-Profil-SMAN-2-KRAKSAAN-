<?php
include "../../config/koneksi.php";


$divisi = $_POST['divisi'];
$id = $_POST['id'];
$del = $_POST['del'];

$deskripsi = $_POST['deskripsi'];


$nama = basename($_FILES["foto"]["name"]);

$target_directory = "../../img/program/";
$target_file = $target_directory . basename($_FILES["foto"]["name"]);   //name is to get the file name of uploaded file

$newfilename = $target_directory . $nama;
$newdel = $target_directory . $del;
//move_uploaded_file($_FILES["file"]["tmp_name"],$newfilename);   // tmp_name is the file temprory stored in the server
// if ($status == 'Y') {
//     $cb = 'Y';
// } else {
//     $cb = 'T';
// }
//Now to check if uploaded or not

if (move_uploaded_file($_FILES["foto"]["tmp_name"], $newfilename)) {
    $sql = mysqli_query($con, "update program set divisi='$divisi', deskripsi='$deskripsi', foto='$nama' where id_program='$id'");
    unlink($newdel);
    //     $sql = mysqli_query($con, "insert into berita
    // (id_kategori,berita,foto,deskripsi,hari,tanggal,jam,penulis,status,dibaca)
    // value
    // ('$kat','$berita','$nama','$deskripsi','$hari_ini','$tgl','$jam','Admin','$cb','0')");
}