<?php
include "../../config/koneksi.php";

$id_user = $_POST['id_user'];
$namalengkap       = $_POST['nama_lengkap'];
$user       = $_POST['username'];
$md5       = md5($_POST['pass']);
$pass       = $_POST['pass'];

mysqli_query($con, "update user set nama_lengkap='$namalengkap' where id_user='$id_user'");