<?php
include "../../config/koneksi.php";


$divisi = $_POST['divisi'];

$deskripsi = $_POST['deskripsi'];


$nama = basename($_FILES["foto"]["name"]);

$target_directory = "../../img/program/";
$target_file = $target_directory . basename($_FILES["foto"]["name"]);   //name is to get the file name of uploaded file

$newfilename = $target_directory . $nama;
// $newdel = $target_directory . $del;

if (move_uploaded_file($_FILES["foto"]["tmp_name"], $newfilename)) {
    mysqli_query($con, "insert into program(divisi,foto,deskripsi) value('$divisi','$nama','$deskripsi')");

    // unlink($newdel);
    //     $sql = mysqli_query($con, "insert into berita
    // (id_kategori,berita,foto,deskripsi,hari,tanggal,jam,penulis,status,dibaca)
    // value
    // ('$kat','$berita','$nama','$deskripsi','$hari_ini','$tgl','$jam','Admin','$cb','0')");
}
// mysqli_query($con, "update visi set visi='$visi', misi='$misi', tujuan='$tujuan' where id_visi='$idv'");