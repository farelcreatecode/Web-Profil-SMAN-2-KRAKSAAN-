<?php
include "../../config/koneksi.php";

$sarpras = $_POST['sarpras'];


// mysqli_query($con, "update visi set visi='$visi', misi='$misi', tujuan='$tujuan' where id_visi='$idv'");
mysqli_query($con, "insert into sarpras(sarpras) value('$sarpras')");