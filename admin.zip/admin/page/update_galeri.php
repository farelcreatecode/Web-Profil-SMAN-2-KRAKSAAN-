<?php
include "../../config/koneksi.php";
$id = $_POST['id'];
$ket = $_POST['ket'];


mysqli_query($con, "update galeri set keterangan='$ket' where id_galeri='$id'");
// mysqli_query($con, "insert into vidio(deskripsi,link,status) value('$des','$link','$cek')");