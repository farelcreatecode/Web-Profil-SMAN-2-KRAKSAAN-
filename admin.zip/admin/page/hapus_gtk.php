<?php
include "../../config/koneksi.php";

$id = $_POST['id'];

$a = mysqli_fetch_array(mysqli_query($con, "select * from gtk where id_gtk='$id'"));
$cek = $a['foto'];
$target_directory = "../../img/GTK/";

$newdel = $target_directory . $cek;
mysqli_query($con, "delete from gtk where id_gtk='$id'");
echo 'ok';
unlink($newdel);
// mysqli_query($con, "insert into vidio(deskripsi,link,status) value('$des','$link','$cek')");