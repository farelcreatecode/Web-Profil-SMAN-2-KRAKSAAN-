<?php
include "../../config/koneksi.php";
$id = $_POST['id'];
$ket = $_POST['ket'];

// mysqli_query($con, "update galeri set galeri='$galeri' where id_galeri='$ids'");
// mysqli_query($con, "insert into vidio(deskripsi,link,status) value('$des','$link','$cek')");

$del = $_POST['del'];
// $foto1 = $_POST['foto'];

// $tgl = date('Y-m-d');
// $jam = date('H:i:s');
// $status = $_POST['status'];
$nama = basename($_FILES["foto"]["name"]);

$target_directory = "../../img/galeri/";
$target_file = $target_directory . basename($_FILES["foto"]["name"]);   //name is to get the file name of uploaded file
// $filetype = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
$newfilename = $target_directory . $nama;
$newdel = $target_directory . $del;
//move_uploaded_file($_FILES["file"]["tmp_name"],$newfilename);   // tmp_name is the file temprory stored in the server

//Now to check if uploaded or not

if (move_uploaded_file($_FILES["foto"]["tmp_name"], $newfilename)) {
    $sql = mysqli_query($con, "update galeri set keterangan='$ket', foto='$nama' where id_galeri='$id'");
    unlink($newdel);
}