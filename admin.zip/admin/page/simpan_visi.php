<?php
include "../../config/koneksi.php";

    $idv = $_POST['idv'];
    $visi = $_POST['visi'];
    $misi = $_POST['misi'];
    $tujuan = $_POST['tujuan'];

    mysqli_query($con, "update visi set visi='$visi', misi='$misi', tujuan='$tujuan' where id_visi='$idv'");