<?php
include "../../config/koneksi.php";
$id = $_POST['id'];
$delfav = $_POST['delfav'];
$nama = basename($_FILES["foto"]["name"]);

$target_directory = "../../img/";
$newfilename = $target_directory . $nama;
$newdel = $target_directory . $delfav;


if (move_uploaded_file($_FILES["foto"]["tmp_name"], $newfilename)) {
    $sql = mysqli_query($con, "update identitas set favicon='$nama' where id_identitas='$id'");
    unlink($newdel);
}