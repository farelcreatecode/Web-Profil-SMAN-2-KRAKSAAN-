<?php
include "../../config/koneksi.php";


$id = $_POST['id'];
$a = mysqli_fetch_array(mysqli_query($con, "select * from agenda where id_agenda='$id'"));
$cek = $a['tanggal'];
$pisah = explode(' - ', $cek);
?>




<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Tanggal Mulai</label>
    <div class="col-md-10 col-sm-10 ">
        <div class="form-group">
            <div class='input-group date' id='myDatepicker4'>
                <input type='text' class="form-control" name="mulai1" value="<?= $pisah[0] ?>" />
                <span class="input-group-addon">
                    <span class="fa fa-calendar"></span>
                </span>
            </div>
        </div>

    </div>
</div>
<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Tanggal Selesai</label>
    <div class="col-md-10 col-sm-10 ">

        <div class="form-group">
            <div class='input-group date' id='myDatepicker5'>
                <input type='text' class="form-control" name="akhir1" value="<?= $pisah[1] ?>" />
                <span class="input-group-addon">
                    <span class="fa fa-calendar"></span>
                </span>
            </div>
        </div>
    </div>
</div>
<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Nama Agenda</label>
    <div class="col-md-10 col-sm-10 ">
        <input type="hidden" name="id_agenda" id="id_agenda" value="<?= $a['id_agenda'] ?>">
        <textarea rows="5" class="form-control ckeditor" name="agenda1"><?= $a['agenda'] ?></textarea>
    </div>
</div>
<div class="form-group row">
    <label class="col-form-label col-md-2 col-sm-2 ">Penanggung Jawab</label>
    <div class="col-md-10 col-sm-10 ">
        <select class="form-control" name="pj1">
            <option value="0">-</option>
            <?php
            $cek = mysqli_query($con, "select * from gtk");
            while ($pj = mysqli_fetch_array($cek)) { ?>
            <option value="<?= $pj['id_gtk'] ?>" <?php
                                                        if ($a['id_gtk'] == $pj['id_gtk']) {
                                                            echo "selected";
                                                        }
                                                        ?>><?= $pj['nama'] ?></option>
            <?php  } ?>
        </select>
    </div>
</div>
<script type="text/javascript">
$(function() {
    $('#myDatepicker').datetimepicker();
});

// $('#myDatepicker2').datetimepicker({
//     format: 'DD MMMM YYYY'
// });

// $('#myDatepicker3').datetimepicker({
//     format: 'DD MMMM YYYY'
// });
$('#myDatepicker4').datetimepicker({
    format: 'DD MMMM YYYY'
});

$('#myDatepicker5').datetimepicker({
    format: 'DD MMMM YYYY'
});

// $('#myDatepicker4').datetimepicker({
//     ignoreReadonly: true,
//     allowInputToggle: true
// });

// $('#datetimepicker6').datetimepicker();

// $('#datetimepicker7').datetimepicker({
//     useCurrent: false
// });

// $("#datetimepicker6").on("dp.change", function(e) {
//     $('#datetimepicker7').data("DateTimePicker").minDate(e.date);
// });

// $("#datetimepicker7").on("dp.change", function(e) {
//     $('#datetimepicker6').data("DateTimePicker").maxDate(e.date);
// });
</script>