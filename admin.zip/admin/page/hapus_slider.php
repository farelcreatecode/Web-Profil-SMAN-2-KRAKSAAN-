<?php
include "../../config/koneksi.php";

$id = $_POST['id'];
$a = mysqli_fetch_array(mysqli_query($con, "select * from slider where id='$id'"));
$cek = $a['nama'];
$target_directory = "../../img/slider/";

$newdel = $target_directory . $cek;
mysqli_query($con, "delete from slider where id='$id'");
echo 'ok';
unlink($newdel);
// mysqli_query($con, "insert into vidio(deskripsi,link,status) value('$des','$link','$cek')");