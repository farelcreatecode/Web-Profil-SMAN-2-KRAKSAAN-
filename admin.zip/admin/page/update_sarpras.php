<?php
include "../../config/koneksi.php";
$ids = $_POST['id_sarpras'];
$sarpras = $_POST['sarpras1'];


mysqli_query($con, "update sarpras set sarpras='$sarpras' where id_sarpras='$ids'");
// mysqli_query($con, "insert into vidio(deskripsi,link,status) value('$des','$link','$cek')");