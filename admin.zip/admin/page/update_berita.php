<?php
include "../../config/koneksi.php";

$id = $_POST['id'];
$berita = $_POST['judul'];
$deskripsi = $_POST['deskripsi'];
$kat = $_POST['kat'];
$status = $_POST['status'];

$sql = mysqli_query($con, "update berita set berita='$berita', deskripsi='$deskripsi', id_kategori='$kat', status='$status' where id_berita='$id'");