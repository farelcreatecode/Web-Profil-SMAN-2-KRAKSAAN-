<?php
include "../config/koneksi.php";
$id = $_POST['id'];
$kat = $_POST['kat'];
$judul = $_POST['judul'];
$isi = $_POST['isi'];
$tgl = date('Y-m-d');


// mysqli_query($con, "update galeri set keterangan='$ket' where id_galeri='$id'");
// mysqli_query($con, "insert into vidio(deskripsi,link,status) value('$des','$link','$cek')");
$sql = mysqli_query($con, "update profil_info set kategori='$kat',judul='$judul', detail='$isi', waktu='$tgl' where id_profil='$id'");