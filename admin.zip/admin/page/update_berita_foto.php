<?php
include "../../config/koneksi.php";


$id = $_POST['id'];
$berita = $_POST['judul'];
$deskripsi = $_POST['deskripsi'];
$kat = $_POST['kat'];
$del = $_POST['del'];
// $foto1 = $_POST['foto'];

// $tgl = date('Y-m-d');
// $jam = date('H:i:s');
$status = $_POST['status'];
$nama = basename($_FILES["foto"]["name"]);

$target_directory = "../../img/berita/";
$target_file = $target_directory . basename($_FILES["foto"]["name"]);   //name is to get the file name of uploaded file
// $filetype = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
$newfilename = $target_directory . $nama;
$newdel = $target_directory . $del;
//move_uploaded_file($_FILES["file"]["tmp_name"],$newfilename);   // tmp_name is the file temprory stored in the server

//Now to check if uploaded or not

if (move_uploaded_file($_FILES["foto"]["tmp_name"], $newfilename)) {
    $sql = mysqli_query($con, "update berita set berita='$berita', deskripsi='$deskripsi', foto='$nama', id_kategori='$kat', status='$status' where id_berita='$id'");
    unlink($newdel);
}