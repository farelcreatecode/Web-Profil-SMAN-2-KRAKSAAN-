<?php
include "../../config/koneksi.php";

// $nama       = $_POST['namalengkap'];
// $user       = $_POST['username'];
// $md5       = md5($_POST['pass']);
// $pass       = $_POST['pass'];
// $kategori = $_POST['username'];

$id = $_POST['id'];
$namalengkap = $_POST['namalengkap'];
$vjk = $_POST['vjk'];
$vnip = $_POST['vnip'];
$vnik = $_POST['vnik'];
$vnuptk = $_POST['vnuptk'];
$vtempat = $_POST['vtempat'];
$vtanggal = $_POST['vtanggal'];
$vagama = $_POST['vagama'];
$valamat = $_POST['valamat'];
$vdesa = $_POST['vdesa'];
$vkecamatan = $_POST['vkecamatan'];
$vkabupaten = $_POST['vkabupaten'];
$vprovinsi = $_POST['vprovinsi'];
$vkodepos = $_POST['vkodepos'];
$vno_ijazah = $_POST['vno_ijazah'];
$vnim = $_POST['vnim'];
$vnama_pt = $_POST['vnama_pt'];
$vprodi = $_POST['vprodi'];
$vthn_masuk = $_POST['vthn_masuk'];
$vthn_keluar = $_POST['vthn_keluar'];
$vstatus_peg = $_POST['vstatus_peg'];
$vjenis_ptk = $_POST['vjenis_ptk'];
$vsk_peg = $_POST['vsk_peg'];
$vtmt_peg = $_POST['vtmt_peg'];
$vpengangkat_peg = $_POST['vpengangkat_peg'];
$vmapel_peg = $_POST['vmapel_peg'];
$vtugas_tambahan = $_POST['vtugas_tambahan'];
$vno_tugas = $_POST['vno_tugas'];
$vtmt_tugas = $_POST['vtmt_tugas'];
$vstatus_tugas = $_POST['vstatus_tugas'];
$vno_hp = $_POST['vno_hp'];
$vemail = $_POST['vemail'];
$voffice = $_POST['voffice'];
$vnama_fb = $_POST['vnama_fb'];
$vurl_fb = $_POST['vurl_fb'];
$vnama_ig = $_POST['vnama_ig'];
$vurl_ig = $_POST['vurl_ig'];
$vpassword = $_POST['vpassword'];
$md5pass = md5($_POST['vpassword']);
$namafoto = basename($_FILES["foto"]["name"]);

$target_directory = "../../img/gtk/";
$target_file = $target_directory . basename($_FILES["foto"]["name"]);   //name is to get the file name of uploaded file
$filetype = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
$newfilename = $target_directory . $namafoto;
// $newdel = $target_directory . $del;

// mysqli_query($con, "INSERT INTO user(nama_lengkap,username,password,pass) value('$nama','$user','$md5','$pass')");

if (move_uploaded_file($_FILES["foto"]["tmp_name"], $newfilename)) {
    $sql = mysqli_query($con, "insert into gtk
(id_gtk,nama,jk,nip,nik,nuptk,tempat,tanggal,agama,
alamat,desa,kecamatan,kabupaten,provinsi,kodepos,no_ijazah,
nim,nama_pt,prodi,thn_masuk,thn_keluar,status_peg,jenis_ptk,
sk_peg,tmt_peg,pengangkat_peg,mapel_peg,tugas_tambahan,no_tugas,
tmt_tugas,status_tugas,no_hp,email,office,nama_fb,url_fb,nama_ig,url_ig,foto,password,pass
)
value
('$id','$namalengkap','$vjk','$vnip','$vnik','$vnuptk','$vtempat','$vtanggal','$vagama'
,'$valamat','$vdesa','$vkecamatan','$vkabupaten','$vprovinsi','$vkodepos','$vno_ijazah'
,'$vnim','$vnama_pt','$vprodi','$vthn_masuk','$vthn_keluar','$vstatus_peg','$vjenis_ptk'
,'$vsk_peg','$vtmt_peg','$vpengangkat_peg','$vmapel_peg','$vtugas_tambahan','$vno_tugas'
,'$vtmt_tugas','$vstatus_tugas','$vno_hp','$vemail','$voffice','$vnama_fb','$vurl_fb'
,'$vnama_ig','$vurl_ig','$namafoto','$vpassword','$md5pass')");
}