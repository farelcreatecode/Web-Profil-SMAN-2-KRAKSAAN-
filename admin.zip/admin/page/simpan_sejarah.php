<?php
include "../../config/koneksi.php";
$id = $_POST['id'];
$sejarah = $_POST['sejarah'];
$del = $_POST['del'];
$nama = basename($_FILES["file"]["name"]);

$target_directory = "../../img/sejarah/";
$target_file = $target_directory . basename($_FILES["file"]["name"]);   //name is to get the file name of uploaded file
$filetype = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
$newfilename = $target_directory . $nama;
$newdel = $target_directory . $del;
//move_uploaded_file($_FILES["file"]["tmp_name"],$newfilename);   // tmp_name is the file temprory stored in the server

//Now to check if uploaded or not

if (move_uploaded_file($_FILES["file"]["tmp_name"], $newfilename)) {
    $sql = mysqli_query($con, "update sejarah set sejarah='$sejarah', foto='$nama' where id_sejarah='$id'");
    unlink($newdel);
} else {
    $sql = mysqli_query($con, "update sejarah set sejarah='$sejarah' where id_sejarah='$id'");
}