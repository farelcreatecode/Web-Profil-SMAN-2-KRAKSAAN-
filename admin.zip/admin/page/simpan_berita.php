<?php
include "../config/koneksi.php";

$hari = date("D");

switch ($hari) {
    case 'Sun':
        $hari_ini = "Minggu";
        break;

    case 'Mon':
        $hari_ini = "Senin";
        break;

    case 'Tue':
        $hari_ini = "Selasa";
        break;
        
        case 'Wed':
        $hari_ini = "Rabu";
        break;
        
        case 'Thu':
            $hari_ini = "Kamis";
            break;
            
            case 'Fri':
                $hari_ini = "Jumat";
        break;

        case 'Sat':
            $hari_ini = "Sabtu";
            break;
            
            default:
            $hari_ini = "Tidak di ketahui";
            break;
        }
        
// $hari_ini = date("D");

$berita = $_POST['judul'];
$deskripsi = $_POST['deskripsi'];
$kat = $_POST['kat'];

$tgl = date('Y-m-d');
$jam = date('H:i:s');
$nama = basename($_FILES["foto"]["name"]);

$target_directory = "../../img/";
$newfilename = $target_directory . $nama;


if (move_uploaded_file($_FILES["foto"]["tmp_name"], $newfilename)) {
    $sql = mysqli_query($con, "insert into berita (kategori,judul,foto,isi_berita,hari,tanggal,jam,penulis,status,dibaca)
value('$kat','$berita','$nama','$deskripsi','$hari_ini','$tgl','$jam','Admin','N','0')");
}