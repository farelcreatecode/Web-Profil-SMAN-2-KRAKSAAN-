<script src="notif/Notifier.min.js"></script>
<script src="notif/Notifier.js"></script>

<script src="notif/sweetalert2.all.min.js"></script>
<script src="notif/sweetalert2.all.js"></script>
<script src="notif/sweetalert2.js"></script>
<script src="notif/sweetalert2.min.js"></script>
<link rel='stylesheet' href='css/sweetalert2.min.css'>

<script type="text/javascript" src="notif/bootstrap-growl.min.js"></script>
<script type="text/javascript" src="notif/notification.js"></script>
<link rel="stylesheet" type="text/css" href="notif/notification.css">