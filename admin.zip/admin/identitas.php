<!DOCTYPE html>
<html lang="en">
<?php
// session_start();

include "config/koneksi.php";
$cs = mysqli_fetch_array(mysqli_query($con, "select * from identitas"));
// $id_user = $_SESSION['id_user'];
// $user = mysqli_fetch_array(mysqli_query($con, "select * from user where id_user='$id_user'"));
?>
<head>
    <meta charset="utf-8">
    <title><?= $cs['nama_sekolah']?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->

    <!-- Favicon -->
    <link href="../img/<?= $cs['favicon']?>" rel="icon">
    
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php
        include "menu.php"
        ?>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <a href="beranda" class="navbar-brand d-flex d-lg-none me-4">
                    <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
                </a>
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <i class="fa fa-bars"></i>
                </a>
                <!-- <form class="d-none d-md-flex ms-4">
                    <input class="form-control border-0" type="search" placeholder="Search">
                </form> -->
                <div class="navbar-nav align-items-center ms-auto">
                    <div class="nav-item dropdown">
                        <!-- <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-envelope me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Message</span>
                        </a> -->
                        <!-- <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                    <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div>
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                    <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div>
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                    <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div>
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item text-center">See all message</a>
                        </div> -->
                    </div>
                    <div class="nav-item dropdown">
                        <!-- <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-bell me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Notificatin</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">Profile updated</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">New user added</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">Password changed</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item text-center">See all notifications</a>
                        </div> -->
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <img class="rounded-circle me-lg-2" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                            <span class="d-none d-lg-inline-flex">John Doe</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <!-- <a href="#" class="dropdown-item">My Profile</a>
                            <a href="#" class="dropdown-item">Settings</a> -->
                            <a onclick="logout()"class="dropdown-item" href="#">Log Out</a>
                        </div>
                    </div>
                </div>
            </nav>
            <!-- Navbar End -->


<!--Conten / Isi-->
<!-- <div class="badan"></div> -->

<div class="container-fluid pt-4 px-4">
    <div class="row">
        <div aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="."><i class="fa fa-home"></i> Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Profil Sekolah</li>
            </ol>
        </div>
    </div>
</div>

    <!-- Widgets Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-md-6 col-xl-12">
            <div class="h-100 bg-light rounded p-4">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <h4 class="mb-1">Identitas Lembaga</h>
                    <h6 class="mb-1">Update Data Lembaga || <small>Pastikan Semua Form Terisi</small></h6>                    
                </div>
                <hr>
                
                <?php
                    $no = 1;
                    $sql = mysqli_query($con, "Select * from identitas");
                    $rs = mysqli_fetch_array($sql);
                    ?>


                <form class="form-label-left input_mask" id="form_identitas" method="POST" enctype="multipart/form-data">
                    <div class="form-group row mb-1">
                        <label class="col-form-label col-md-2 col-sm-2 ">NPSN</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="hidden" class="form-control" name="idi" id="id"
                                value="<?php echo $rs['id_identitas']; ?>" />
                            <input type="text" class="form-control" name="nps" value="<?php echo $rs['npsn']; ?>"
                                placeholder="NPSN" />
                        </div>

                        <label class="col-form-label col-md-2 col-sm-2 ">Nama Sekolah</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" name="nms"
                                value="<?php echo $rs['nama_sekolah']; ?>" />
                        </div>
                    </div>
                    <div class="form-group row mb-1">
                        <label class="col-form-label col-md-2 col-sm-2 ">Website</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" name="web"
                                value="<?php echo $rs['nama_website']; ?>" />
                        </div>

                        <label class="col-form-label col-md-2 col-sm-2 ">Email</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" name="eml" value="<?php echo $rs['email']; ?>" />
                        </div>
                    </div>

                    <div class="form-group row mb-1">
                        <label class="col-form-label col-md-2 col-sm-2 ">Alamat</label>
                        <div class="col-md-10 col-sm-10 ">
                            <textarea rows="3" class="form-control ckeditor"
                                name="alm"><?php echo $rs['alamat']; ?></textarea>
                        </div>
                    </div>
                    <div class="form-group row mb-1">
                        <label class="col-form-label col-md-2 col-sm-2 ">Deskripsi Sekolah</label>
                        <div class="col-md-10 col-sm-10 ">
                            <textarea rows="5" class="form-control ckeditor"
                                name="deskripsi_sekolah"><?php echo $rs['deskripsi_sekolah']; ?></textarea>
                        </div>
                    </div>
                    <div class="form-group row mb-1">
                        <label class="col-form-label col-md-2 col-sm-2 ">Desa</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" name="des" value="<?php echo $rs['desa']; ?>" />
                        </div>

                        <label class="col-form-label col-md-2 col-sm-2 ">Kecamatan</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" name="kec"
                                value="<?php echo $rs['kecamatan']; ?>" />
                        </div>
                    </div>
                    <div class="form-group row mb-1">
                        <label class="col-form-label col-md-2 col-sm-2 ">Kabupaten</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" name="kab"
                                value="<?php echo $rs['kabupaten']; ?>" />
                        </div>

                        <label class="col-form-label col-md-2 col-sm-2 ">Akreditasi</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" name="akr"
                                value="<?php echo $rs['akreditasi']; ?>" />
                        </div>
                    </div>                    
                    <div class="form-group row mb-1">
                        <label class="col-form-label col-md-2 col-sm-2 ">Facebook</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" name="fac" value="<?php echo $rs['facebook']; ?>" />
                        </div>

                        <label class="col-form-label col-md-2 col-sm-2 ">Nama KS</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" name="nmk" value="<?php echo $rs['nama_ks']; ?>" />
                        </div>
                    </div>
                    <div class="form-group row mb-1">
                        <label class="col-form-label col-md-2 col-sm-2 ">No. Telp</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="text" class="form-control" name="not" value="<?php echo $rs['no_telp']; ?>" />
                        </div>

                </form>
                    </div>
                    <div class="form-group row mb-1">
                        <label class="col-form-label col-md-2 col-sm-2 ">Favicon</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="file" id="fav" onchange="favicon()" class="form-control mb-2">
                            <input type="hidden" id="delfav" value="<?= $rs['favicon']?>" >
                            <img src="../img/<?= $rs['favicon']?>" alt="" style="height:50px" class="img-fluid img-thumbnail">
                        </div>

                        <label class="col-form-label col-md-2 col-sm-2 ">Logo Website</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="file" id="web" class="form-control mb-2" onchange="web()">
                            <input type="hidden" id="delweb" value="<?= $rs['logo_web']?>" >
                            <img src="../img/<?= $rs['logo_web']?>" style="height:50px" alt="" class="img-fluid img-thumbnail">
                        </div>
                    </div>
                    <div class="form-group row mb-1">
                        <label class="col-form-label col-md-2 col-sm-2 ">Logo Sekolah</label>
                        <div class="col-md-4 col-sm-4 ">
                            <input type="file" id="logo_sekolah" onchange="logo_sekolah()" class="form-control mb-2">
                            <input type="hidden" id="delsekolah" value="<?= $rs['logo_sekolah']?>" >
                            <img src="../img/<?= $rs['logo_sekolah']?>" alt="" style="height:50px" class="img-fluid img-thumbnail">
                        </div>      
                    </div>

                    <div class="ln_solid"></div>
                    <div class="form-group row mb-1">
                        <div class="col-md-12 col-sm-12 ">
                            <!-- <button type="button" class="btn btn-primary">Cancel</button>
                            <button class="btn btn-primary" type="reset">Reset</button> -->
                            <button type="submit" onclick="update()" class="btn btn-info"><i class="fa fa-save"></i> Update</button>
                        </div>
                    </div>
                
                
            </div>
        </div>
        
    </div>
</div>
<!-- Widgets End -->
<!--Tutup Conten / Isi-->


            <!-- Footer Start -->
            <?php include "buttom.php"?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    
</body>

</html>
<script>
function update(){
    $.ajax({
        type: 'POST',
        url: "page/identitas.php",
        data: $('#form_identitas').serialize(),
        success: function() {
            Swal.fire({
            title: "Tersimpan",
            icon: "success",
            timer: 1500
            });
            // $("#tambah_vidio").hide();
            // $("#tambahvidio")[0].reset();
            setTimeout(function(){
                location.reload(true);
                }, 1500);
            
            
        },
        error: function(response) {
            console.log(response.responseText);
        }
    });    
}
function favicon(){
    var id = $('#id').val();
    var delfav = $('#delfav').val();
    var fav = $('#fav').prop('files')[0];

    var form_data = new FormData();
        
    form_data.append("id", id);
    form_data.append("delfav", delfav);
    form_data.append("foto", fav);
    
    $.ajax({
        type: "POST",
        dataType: 'script',
        cache: false,
        contentType: false,
        processData: false,
        data: form_data,
        url: "page/favicon.php",
        success: function() {
            Swal.fire({
            title: "Foto Berhasil Tersimpan",
            icon: "success",
            timer: 1500
            });
            // $("#tambah_media").hide();
            // $("#formtambahmedia")[0].reset();
            setTimeout(function(){
                location.reload(true);
                }, 1500);
        },
        error: function(response) {
            console.log(response.responseText);
        }
    });
    
}
function web(){
    var id = $('#id').val();
    var delweb = $('#delweb').val();
    var web = $('#web').prop('files')[0];

    var form_data = new FormData();
        
    form_data.append("id", id);
    form_data.append("delweb", delweb);
    form_data.append("foto", web);
    
    $.ajax({
        type: "POST",
        dataType: 'script',
        cache: false,
        contentType: false,
        processData: false,
        data: form_data,
        url: "page/web.php",
        success: function() {
            Swal.fire({
            title: "Foto Berhasil Tersimpan",
            icon: "success",
            timer: 1500
            });
            // $("#tambah_media").hide();
            // $("#formtambahmedia")[0].reset();
            setTimeout(function(){
                location.reload(true);
                }, 1500);
        },
        error: function(response) {
            console.log(response.responseText);
        }
    });    
}
function logo_sekolah(){
    var id = $('#id').val();
    var delsekolah = $('#delsekolah').val();
    var logo_sekolah = $('#logo_sekolah').prop('files')[0];

    var form_data = new FormData();
        
    form_data.append("id", id);
    form_data.append("delsekolah", delsekolah);
    form_data.append("foto", logo_sekolah);
    
    $.ajax({
        type: "POST",
        dataType: 'script',
        cache: false,
        contentType: false,
        processData: false,
        data: form_data,
        url: "page/logo_sekolah.php",
        success: function() {
            Swal.fire({
            title: "Foto Berhasil Tersimpan",
            icon: "success",
            timer: 1500
            });
            // $("#tambah_media").hide();
            // $("#formtambahmedia")[0].reset();
            setTimeout(function(){
                location.reload(true);
                }, 1500);
        },
        error: function(response) {
            console.log(response.responseText);
        }
    }); 
}
</script>