<!DOCTYPE html>
<html lang="en">
<?php
// session_start();

include "config/koneksi.php";
$cs = mysqli_fetch_array(mysqli_query($con, "select * from identitas"));
// $id_user = $_SESSION['id_user'];
// $user = mysqli_fetch_array(mysqli_query($con, "select * from user where id_user='$id_user'"));
?>
<head>
    <meta charset="utf-8">
    <title><?= $cs['nama_sekolah']?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->

    <!-- Favicon -->
    <link href="../img/<?= $cs['favicon']?>" rel="icon">
    
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php
        include "menu.php"
        ?>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <a href="beranda" class="navbar-brand d-flex d-lg-none me-4">
                    <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
                </a>
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <i class="fa fa-bars"></i>
                </a>
                <!-- <form class="d-none d-md-flex ms-4">
                    <input class="form-control border-0" type="search" placeholder="Search">
                </form> -->
                <div class="navbar-nav align-items-center ms-auto">
                    <div class="nav-item dropdown">
                        <!-- <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-envelope me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Message</span>
                        </a> -->
                        <!-- <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                    <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div>
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                    <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div>
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                    <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div>
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item text-center">See all message</a>
                        </div> -->
                    </div>
                    <div class="nav-item dropdown">
                        <!-- <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-bell me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Notificatin</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">Profile updated</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">New user added</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">Password changed</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item text-center">See all notifications</a>
                        </div> -->
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <img class="rounded-circle me-lg-2" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                            <span class="d-none d-lg-inline-flex">John Doe</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <!-- <a href="#" class="dropdown-item">My Profile</a>
                            <a href="#" class="dropdown-item">Settings</a> -->
                            <a onclick="logout()"class="dropdown-item" href="#">Log Out</a>
                        </div>
                    </div>
                </div>
            </nav>
            <!-- Navbar End -->


<!--Conten / Isi-->
<!-- <div class="badan"></div> -->

<div class="container-fluid pt-4 px-4">
    <div class="row">
        <div aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="."><i class="fa fa-home"></i> Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Berita</li>
            </ol>
        </div>
    </div>
</div>


    <!-- berita Add -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-md-6 col-xl-12">
            <div class="h-100 bg-light rounded p-4">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <h4 class="mb-1">Tambah Berita</h4>
                    <h6 class="mb-1">Form Tambah Berita || <small>Pastikan Semua Form Terisi</small></h6>
                    <!-- <h6 class="mb-1"><button class="btn btn-info" id="tambah"><i class="fa fa-plus"></i> Tambah Berita</button></h6> -->
                </div>
                <hr>
                <form class="form-label-left input_mask" method="POST" id="tambahberita" enctype="multipart/form-data">
                    <div class="form-group row mb-2">
                        <label class="col-form-label col-md-2 col-sm-2 ">Judul Berita</label>
                        <div class="col-md-10 col-sm-10 ">
                            <input type="text" name="judul" id="judul" placeholder="Judul Berita" class="form-control">
                        </div>
                    </div>
                    <div class="form-group row mb-2">
                        <label class="col-form-label col-md-2 col-sm-2 ">Deskripsi</label>
                        <div class="col-md-10 col-sm-10 ">
                            <textarea rows="5" class="form-control ckeditor" placeholder="Deskripsi" name="deskripsi"
                                id="deskripsi"></textarea>
                        </div>
                    </div>
                    <div class="form-group row mb-2">
                        <label class="col-form-label col-md-2 col-sm-2 ">Kategori</label>
                        <div class="col-md-10 col-sm-10 ">
                            <select name="kat" class="form-control" id="kat">
                                <option value="">PILIH KATEGORI</option>
                                <?php
                                $cari = mysqli_query($con, 'select * from kategori');
                                while ($r = mysqli_fetch_array($cari)) {
                                ?>
                                <option value="<?= $r['id_kategori'] ?>"><?= $r['kategori'] ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row mb-2">
                        <label class="col-form-label col-md-2 col-sm-2 ">Foto</label>
                        <div class="col-md-10 col-sm-10 ">
                            <input type="file" name="foto" id="foto" class="form-control foto">
                        </div>
                    </div>


                </form>
                <div class="ln_solid"></div>
                <div class="form-group row">
                    <div class="col-md-12 col-sm-12 ">
                        <!-- <button type="button" class="btn btn-primary">Cancel</button>
                            <button class="btn btn-primary" type="reset">Reset</button> -->
                        <button onclick="tambah_berita()" class="btn btn-info"><i class="fa fa-save"></i>
                            Simpan</button>
                    </div>
                </div>
                
            </div>
        </div>
        
    </div>
</div>
<!-- berita Add -->
<!--Tutup Conten / Isi-->


            <!-- Footer Start -->
            <?php include "buttom.php"?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    <link href="js/Datatable/datatables.css" rel="stylesheet"> 
    <script src="js/Datatable/datatables.js"></script>
    <script src="js/tinymce/tinymce.min.js"></script>
    
</body>

</html>
<script>
tinymce.init({
  selector: 'textarea#deskripsi',
  height: 500,
  plugins: [
    'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
    'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
    'insertdatetime', 'media', 'table', 'help', 'wordcount'
  ],
  toolbar: 'undo redo | blocks | ' +
  'bold italic backcolor | alignleft aligncenter ' +
  'alignright alignjustify | bullist numlist outdent indent | ' +
  'removeformat | help',
  content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:16px }'
});
    
function tambah_berita() {
    
    Swal.fire({
        title: 'Apakah Anda Yakin?',
        text: "Tambah Data Tersebut",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Add it!'
    }).then((result) => {
        if (result.isConfirmed) {
            var kat = $('#kat').val();
            var judul = $('#judul').val();
            // var deskripsi = $('#deskripsi').val();
            var deskripsi = tinymce.get('deskripsi').getContent();
            var foto = $('#foto').prop('files')[0];

            var form_data = new FormData();
            
            form_data.append("foto", foto);
            form_data.append("judul", judul);
            form_data.append("deskripsi", deskripsi);
            form_data.append("kat", kat);
            $.ajax({
                type: "POST",
                dataType: 'script',
                cache: false,
                contentType: false,
                processData: false,
                data: form_data,
                url: "page/simpan_berita.php",
                success: function() {

                    Swal.fire({
                    title: "Tersimpan",
                    icon: "success",
                    timer: 1500
                    });
                    // $("#tambah_media").hide();
                    // $("#formtambahmedia")[0].reset();
                    setTimeout(function(){
                        location.reload(true);
                        }, 1500);
                },
                error: function(response) {
                    console.log(response.responseText);
                }
            });
        }
    });
}

</script>