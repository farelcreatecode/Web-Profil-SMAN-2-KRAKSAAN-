<?php
session_start();
$id_user = $_SESSION['id_user'];
$user = mysqli_fetch_array(mysqli_query($con, "select * from user where id_user='$id_user'"));
// $identitas = mysqli_fetch_array(mysqli_query($con, "select * from identitas"));
if ($_SESSION['status'] != 'login') {
    header('location:login');
}
?>
<div class="sidebar pe-4 pb-3">
    <nav class="navbar bg-light navbar-light">
        <a href="beranda" class="navbar-brand mx-4 mb-3">
            <h5 class="text-primary"><i class="fa fa-hashtag me-2"></i><?= $cs['nama_sekolah']?></h5>
        </a>
        <div class="d-flex align-items-center ms-4 mb-4">
            <div class="position-relative">
                <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                <div class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1"></div>
            </div>
            <div class="ms-3">
                <!-- <h6 class="mb-0"><?= $user['nama_lengkap']?></h6> -->
                <h6 class="mb-0">Jhon Lenong</h6>
                <span>Admin</span>
            </div>
        </div>
        <div class="navbar-nav w-100 ">
            <a href="beranda" class="nav-item nav-link" id="beranda" onclick="tombol()"><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-laptop me-2"></i>Profil Sekolah</a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="identitas" class="dropdown-item" id="identitas">Identitas Lembaga</a>
                    <!-- <a href="sejarah" class="dropdown-item" id="sejarah">Sejarah</a> -->
                    <a href="sambutan" class="dropdown-item" id="sambutan">Sambutan KS</a>
                    <a href="sambutan" class="dropdown-item" id="ks">Kepala Sekolah</a>
                    <a href="sambutan" class="dropdown-item" id="komite">Komite Sekolah</a>
                    <a href="vidio" class="dropdown-item" id="vidio">Vidio Profil</a>
                    <a href="visi" class="dropdown-item" id="visi">Visi, Misi & Tujuan</a>
                    <a href="media" class="dropdown-item" id="struktur">Media Sekolah</a>
                    <a href="kategori" class="dropdown-item" id="kategori">Kategori</a>
                    <a href="kesiswaan" class="dropdown-item" id="kesiswaan">Kesiswaan / Osis</a>
                    <a href="kurikulum" class="dropdown-item" id="kurikulum">Kurikulum</a>
                    <a href="sarpras" class="dropdown-item" id="sarpras">Sarpras</a>
                    <a href="humas" class="dropdown-item" id="humas">Humas</a>
                    
                </div>
            </div>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-newspaper me-2"></i>Berita</a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="semua_berita" class="dropdown-item" id="semua_berita">Semua Berita</a>
                    <a href="aprov" class="dropdown-item" id="aprov">Aproval Berita</a>
                    <a href="add_berita" class="dropdown-item" id="add_berita">Tambah Berita</a>
                    <!-- <a href="kategori" class="dropdown-item" id="kategori">Kategori Berita</a> -->
                </div>
            </div>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-bell me-2"></i>Informasi</a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="agenda" class="dropdown-item" id="agenda">Agenda</a>
                    <a href="ppdb" class="dropdown-item" id="ppdb">PPDB</a>
                    <a href="beasiswa" class="dropdown-item" id="beasiswa">Beasiswa</a>
                    <a href="raport" class="dropdown-item" id="raport">Raport Siswa</a>
                    <a href="kelulusan" class="dropdown-item" id="kelulusan">Kelulusan</a>
                    <a href="alumni" class="dropdown-item" id="alumni">Alumni</a>
                </div>
            </div>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-user me-2"></i>Pengguna</a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="user" class="dropdown-item" id="user">Admin</a>
                    <a href="gtk" class="dropdown-item" id="gtk">GTK</a>
                    <a href="siswa" class="dropdown-item" id="siswa">Siswa</a>
                </div>
            </div>
            <a href="program" class="nav-item nav-link" id="program"><i class="fa fa-th me-2"></i>Pro Sekolah</a>
            <a href="prestasi" class="nav-item nav-link" id="prestasi"><i class="fa fa-keyboard me-2"></i>Prestasi</a>
            <a href="galeri" class="nav-item nav-link" id="galeri"><i class="fa fa-camera me-2"></i>Galeri</a>
            <a href="slide" class="nav-item nav-link" id="slide"><i class="fa fa-image me-2"></i>Slider</a>
            <a href="download" class="nav-item nav-link" id="download"><i class="fa fa-download me-2"></i>Download</a>
            
        </div>
    </nav>
</div>
<!-- <script src="js/jquery.js"></script> -->
<!-- <script src="https://code.jquery.com/jquery-3.7.1.js"></script> -->
<!-- <link href="js/Datatable/datatables.css" rel="stylesheet"> 
<script src="js/Datatable/datatables.js"></script> -->
<script>
    function tombol(){
        // $('.beranda').classList.add("active");
        $('.beranda').addClass('active');

    }

    $('#beranda').click.(function(){
        // $('.beranda').addClass('active');
        // $('.nav-link').addClass('active');
        $('#beranda').classList.add("active");
    });
</script>

