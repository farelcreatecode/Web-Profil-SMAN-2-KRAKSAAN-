<div class="container-fluid pt-4 px-4">
    <div class="bg-light rounded-top p-4">
        <div class="row">
            <div class="col-12 col-sm-6 text-center text-sm-start">
                &copy; <a href="https://sman2kraksaan.sch.id"><?= date("Y")?></a>, All Right Reserved. 
            </div>
            <div class="col-12 col-sm-6 text-center text-sm-end">
                <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                Designed By <a href="https://sman2kraksaan.sch.id">SMAN 2 Kraksaan</a>
            </br>
            Distributed By <a class="border-bottom" href="https://themewagon.com" target="_blank">ThemeWagon</a>
            </div>
        </div>
    </div>
</div>
<?php
include "notif.php";
?>
<script>
    //untuk menu
    $(document).ready(function{

    });
</script>
<script>
function logout() {
    Swal.fire({
        title: 'Apakah Anda Yakin?',
        text: "Keluar Halaman Ini",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: 'POST',
                url: "page/logout.php",
                success: function() {

                    swal.fire('Sukses', 'Anda Berhasil Logout.', 'success');
                    setTimeout(function() {
                        window.location = "../admin/login";
                    }, 1000);
                    notif.notify("success", "Anda Berhasil Logout");
                },
                error: function(response) {
                    console.log(response.responseText);
                }
            });
        } else {
           
        }
    });
}
</script>
