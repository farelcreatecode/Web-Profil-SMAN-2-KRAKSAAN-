<!DOCTYPE html>
<html lang="en">
<?php
include "notif.php";
include "config/koneksi.php";
$cs = mysqli_fetch_array(mysqli_query($con, "select * from identitas"));

?>

<head>
    <meta charset="utf-8">
    <title><?= $cs['nama_sekolah']?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/<?= $cs['favicon']?>" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sign In Start -->
        <div class="container-fluid">
            <div class="row h-100 align-items-center justify-content-center" style="min-height: 100vh;">
                <div class="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-4">
                    <div class="bg-light rounded p-4 p-sm-5 my-4 mx-3">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <!-- <a href="index.html" class="">
                                <h3 class="text-primary"><i class="fa fa-hashtag me-2"></i><?= $cs['nama_sekolah']?></h3>
                            </a> -->
                            <h3>Sign In</h3>
                        </div>
                        <form method="POST" id="login_form">
                            <div class="form-floating mb-3">
                                <input type="text" name="user" id="user" class="form-control" id="floatingInput" placeholder="name@example.com">
                                <label for="floatingInput">Username</label>
                            </div>
                            <div class="form-floating mb-3">
                                <select name="level" id="level" class="form-control" placeholder="Level">
                                    <!-- <option value="">----- Pilih -----</option> -->
                                    <option value="admin">Admin</option>
                                    <option value="guru">Guru</option>
                                </select>
                                <!-- <input type="text" name="user" id="name" class="form-control" id="floatingInput" placeholder="name@example.com"> -->
                                <label for="level">Level</label>
                            </div>
                            <div class="form-floating mb-4">
                                <input type="password" name="pass" id="pass" class="form-control" id="floatingPassword" placeholder="Password">
                                <label for="floatingPassword">Password</label>
                            </div>
                            <!-- <div class="d-flex align-items-center justify-content-between mb-4">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Check me out</label>
                                </div>
                                <a href="">Forgot Password</a>
                            </div> -->
                        </form>
                            <button id="submit" onclick="masuk()" class="btn btn-primary py-3 w-100 mb-4">Sign In</button>
                            <!-- <p class="text-center mb-0">Don't have an Account? <a href="">Sign Up</a></p> -->
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- Sign In End -->
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
<script>
    function masuk() {
        if ($('#user').val() == "") {
            swal('Oops!', 'Maaf user masih kosong!.', 'error');
            setTimeout(1000);
        } if ($('#pass').val() == "") {
            swal('Oops!', 'Maaf password kosong!.', 'error');
            setTimeout(1000);
        } else {
            $.ajax({
                type: "POST",
                url: 'page/proses_login.php',
                data: $('#login_form').serialize(),
                success: function(data) {
                    if (data == "ok") {
                        swal.fire('Sukses', 'Anda Berhasil Login.', 'success');
                        setTimeout(function() {
                            window.location = "beranda";
                        }, 1000);
                        notif.notify("success", "Anda Berhasil Login");
                    } else {
                        swal.fire('Oops!', 'Username dan Password Salah', 'warning');
                        setTimeout(1000);
                        notif.notify("error", "Anda Gagal Login");
                    }
                }
            });
                
    }
}
</script>