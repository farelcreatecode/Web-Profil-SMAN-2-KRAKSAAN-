<?php
include "config/koneksi.php";
session_start();
	// $username = "sipro@gmail.com";
	// $password = "userdlewer92";

	$user = $_POST['user'];
	$pass = md5($_POST['pass']);
	// $pass = $_POST['pass'];
	// $password = crypt("CV. Sinar Probolinggo",sha1(md5('userdlewer92')));
	// $id = "1";
	// if($email==$username && $pass == $password){
	// 	echo "ok";
	// 	// echo "<script>swal('Gagal', 'Username dan Password Tidak Sama', 'error');</script>";
	// 	// echo "<script>window.location.href = 'login.php'</script>";
		
	// }else{}
	// $sql = mysqli_query($con,"SELECT * FROM user WHERE username='$user' AND password='$pass'");
    $sql = mysqli_query($con,"select * from user WHERE username='$user' AND password='$pass'");
	$row = mysqli_num_rows($sql);
	$data = mysqli_fetch_array($sql);
	
		if($row == 1){
            echo "ok";	
			$_SESSION['id_user'] = $data['id_user'];
			$_SESSION['nama_lengkap'] = $data['nama_lengkap'];
            $_SESSION['username'] = $data['username'];
            // $_SESSION['jabatan'] = $data['jabatan'];
			$_SESSION['status'] = "login";
            
			// echo "<script>swal('Sukses', 'Anda Berhasil Login', 'success');</script>";			
			// echo "<script>setTimeout('window.location.href = beranda.php;',4000)</script>";			
		}else {
			echo "gagal";
		}