<!DOCTYPE html>
<html lang="en">
<?php
// session_start();

include "config/koneksi.php";
$cs = mysqli_fetch_array(mysqli_query($con, "select * from identitas"));
// $id_user = $_SESSION['id_user'];
// $user = mysqli_fetch_array(mysqli_query($con, "select * from user where id_user='$id_user'"));
?>
<head>
    <meta charset="utf-8">
    <title><?= $cs['nama_sekolah']?></title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->

    <!-- Favicon -->
    <link href="../img/<?= $cs['favicon']?>" rel="icon">
    
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <?php
        include "menu.php"
        ?>
        <!-- Sidebar End -->


        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <a href="beranda" class="navbar-brand d-flex d-lg-none me-4">
                    <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
                </a>
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <i class="fa fa-bars"></i>
                </a>
                <!-- <form class="d-none d-md-flex ms-4">
                    <input class="form-control border-0" type="search" placeholder="Search">
                </form> -->
                <div class="navbar-nav align-items-center ms-auto">
                    <div class="nav-item dropdown">
                        <!-- <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-envelope me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Message</span>
                        </a> -->
                        <!-- <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                    <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div>
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                    <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div>
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <div class="d-flex align-items-center">
                                    <img class="rounded-circle" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                                    <div class="ms-2">
                                        <h6 class="fw-normal mb-0">Jhon send you a message</h6>
                                        <small>15 minutes ago</small>
                                    </div>
                                </div>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item text-center">See all message</a>
                        </div> -->
                    </div>
                    <div class="nav-item dropdown">
                        <!-- <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-bell me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Notificatin</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">Profile updated</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">New user added</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal mb-0">Password changed</h6>
                                <small>15 minutes ago</small>
                            </a>
                            <hr class="dropdown-divider">
                            <a href="#" class="dropdown-item text-center">See all notifications</a>
                        </div> -->
                    </div>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <img class="rounded-circle me-lg-2" src="img/user.jpg" alt="" style="width: 40px; height: 40px;">
                            <span class="d-none d-lg-inline-flex">John Doe</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                            <!-- <a href="#" class="dropdown-item">My Profile</a>
                            <a href="#" class="dropdown-item">Settings</a> -->
                            <a onclick="logout()"class="dropdown-item" href="#">Log Out</a>
                        </div>
                    </div>
                </div>
            </nav>
            <!-- Navbar End -->


<!--Conten / Isi-->
<!-- <div class="badan"></div> -->

<div class="container-fluid pt-4 px-4">
    <div class="row">
        <div aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="."><i class="fa fa-home"></i> Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Kategori</li>
            </ol>
        </div>
    </div>
</div>

    <!-- Widgets Start -->
<div class="container-fluid pt-4 px-4" id="tambah_kategori">
    <div class="row g-4">
        <div class="col-sm-12 col-md-6 col-xl-12">
            <div class="h-100 bg-light rounded p-4">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <h4 class="mb-1 judul">Tambah Kategori</h4>
                    <h4 class="mb-1 jud">Ubah Kategori</h4>
                </div>
                <hr>
                
                    <div class="form-group row mb-2">
                        <label class="col-form-label col-md-2 col-sm-2 ">Deskripsi</label>
                        <div class="col-md-10 col-sm-10 ">
                        <form id='editkategori'>
                            <div class='tampil'></div>
                        </form>
                <form class="form-label-left input_mask" method="POST" id="tambahkategori" enctype="multipart/form-data">
                            <input type="hidden" id='id_kategori' class="form-control" name="idkategori">
                            <textarea rows="5" id='datakategori' class="form-control ckeditor" name="kategori"></textarea>
                        </div>
                    </div>
                    <!-- <div class="form-group row mb-2">
                        <label class="col-form-label col-md-2 col-sm-2 ">Link</label>
                        <div class="col-md-10 col-sm-10 ">
                            <textarea rows="5" class="form-control ckeditor" name="link"></textarea>
                        </div>
                    </div> -->
                </form>

                <button type="button" class="btn btn-info" id='simpan' onclick="simpankategori()"><i class="fa fa-save"></i> Simpan</button>
                <button type="button" class="btn btn-success" id='edit' onclick="ubahkategori()"><i class="fa fa-save"></i> Ubah</button>
                <button type="button" class="btn btn-warning" id="batal"><i class="fa fa-close"></i>Batal</button>
                
            </div>
        </div>
         
    </div>
</div>
<!-- Widgets End -->
    <!-- kategori Add -->
<div class="container-fluid pt-4 px-4 tabelkategori">
    <div class="row g-4">
        <div class="col-sm-12 col-md-6 col-xl-12">
            <div class="h-100 bg-light rounded p-4">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <h4 class="mb-1">Kategori</h4>
                    <h6 class="mb-1"><button class="btn btn-info" id="tambah"><i class="fa fa-plus"></i> Tambah kategori</button></h6>
                </div>
                <hr>
                <div class="table-responsive table-desi">
                    <table class="table table-hover table-striped table-bordered" id="tabelkategori">
                        <thead>
                            <tr>
                                <th class="text-center">No</th>
                                <th class="text-center">Deskripsi</th>
                                <!-- <th class="text-center">Link</th> -->
                                <!-- <th class="text-center">Status</th> -->
                                <th class="text-center">Aksi</th>


                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            $sql = mysqli_query($con, "select * from kategori
                                                ");
                            while ($c = mysqli_fetch_array($sql)) { ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $c['kategori'] ?></td>
                                <!-- <td class="text-center"><?= $c['link']; ?></td> -->
                                <td>
                                    <a class="edit_data" id="<?= $c['id_kategori'] ?>" href="javascript:void(0)"><i
                                            class="fa fa-edit"></i></a>
                                    <a class="hapus_data" id="<?= $c['id_kategori'] ?>" href="javascript:void(0)"><i
                                            class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                
            </div>
        </div>
        
    </div>
</div>
<!-- kategori Add -->
<!--Tutup Conten / Isi-->


            <!-- Footer Start -->
            <?php include "buttom.php"?>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    
    
</body>

</html>
<script>
    
    $(document).ready(function(){
        $("#tambah_kategori").hide();
        // $(".tampil").hide();
        $(".jud").hide();
        $('#tabelkategori').DataTable();
        // new DataTable('#datatable');
    });
    $('#tambah').click(function(){
        $("#tambah_kategori").slideDown();
        $("#tambah").hide();
        $("#edit").hide();
        $("#simpan").show();
        $(".judul").show();   
        $(".jud").hide();
        $(".tampil").hide();
        $("#id_kategori").show();
        $("#datakategori").show();
    });
    $('#batal').click(function(){
        $("#tambah_kategori").slideUp();
        $(".tabelkategori").slideDown();
        $("#tambah").show();
        $(".tampil").show();
        $("#id_kategori").show();
        $("#datakategori").show();        
    });
    function simpankategori(){
        Swal.fire({
        title: 'Apakah Anda Yakin?',
        text: "Simpan Data Tersebut",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Save it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: 'POST',
                url: "page/simpan_kategori.php",
                data: $('#tambahkategori').serialize(),
                success: function() {
                    Swal.fire({
                    title: "Tersimpan",
                    icon: "success",
                    timer: 1500
                    });
                    // $("#tambah_kategori").hide();
                    // $("#tambahkategori")[0].reset();
                    setTimeout(function(){
                        location.reload(true);
                        }, 1500);
                    
                    
                },
                error: function(response) {
                    console.log(response.responseText);
                }
            });
        } else {

        }
    });
    }
    $('.hapus_data').click(function(){
        Swal.fire({
        title: 'Apakah Anda Yakin?',
        text: "Hapus Data Tersebut",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                var id = $(this).attr('id');
                $.ajax({
                    type: 'POST',
                    url: "page/hapus_kategori.php",
                    data: 'id=' + id,
                    success: function() {

                    Swal.fire({
                    title: "Data Terhapus",
                    icon: "success",
                    timer: 1500
                    });
                   
                    setTimeout(function(){
                        location.reload(true);
                        }, 1500);        
                    },
                    error: function(response) {
                        console.log(response.responseText);
                    }
                });
            }
        });
    });
    $('.edit_data').click(function(){
        var id = $(this).attr('id');
        $("#tambah_kategori").slideDown();
        $("#edit").show();
        $("#tambah").hide();
        $("#simpan").hide();
        $("#id_kategori").hide();
        $("#datakategori").hide();
        $(".tabelkategori").hide();
        $(".judul").hide();
        $(".jud").show();  
        $.ajax({   
            type: 'POST',
            url: "page/tampil_edit_kategori.php",
            data: 'id=' + id,
            success: function(response) {                
                $('.tampil').html(response);
            },
                error: function(response) {
                    console.log(response.responseText);
                }
            });
        
    });
    function ubahkategori(){
        Swal.fire({
        title: 'Apakah Anda Yakin?',
        text: "Update Data Tersebut",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Save it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                type: 'POST',
                url: "page/update_kategori.php",
                data: $('#editkategori').serialize(),
                success: function() {
                    Swal.fire({
                    title: "Tersimpan",
                    icon: "success",
                    timer: 1500
                    });
                    // $("#tambah_kategori").hide();
                    // $("#tambahkategori")[0].reset();
                    setTimeout(function(){
                        location.reload(true);
                        }, 1500);
                    
                    
                },
                error: function(response) {
                    console.log(response.responseText);
                }
            });
        } else {

        }
    });
    }
</script>